## interactive_story_location_specified
* greet
    - utter_greet
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye
	
## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye	


## complete path
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
	- utter_ask_price
* restaurant_search{"price": "less than 300"}
    - slot{"price": "less than 300"}
    - action_search_restaurants
    - slot{"location": "delhi"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye	

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
	- utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}	
    - action_search_restaurants
    - slot{"location": "mumbai"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye

	
## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "delhi","price":"lesser than Rs.300"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "delhi"}
	- slot{"price": "lesser than Rs.300"} 
    - action_search_restaurants
    - slot{"location": "delhi"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye	
	

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "delhi","price":"Rs 300 to 700"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "delhi"}
	- slot{"price": "Rs 300 to 700"} 
    - action_search_restaurants
    - slot{"location": "delhi"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye	
	
    
    
## happy_path
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian", "location": "mumbai","price":"Rs 300 to 700"}
    - slot{"cuisine": "italian"}
    - slot{"location": "mumbai"}
	- slot{"price": "Rs 300 to 700"} 
    - action_search_restaurants
    - slot{"location": "mumbai"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye	





## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "hyderabad"}
    - slot{"location": "hyderabad"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_search_restaurants
    - slot{"location": "hyderabad"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye	
* goodbye
    - utter_goodbye


## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "chennai"}
    - slot{"location": "chennai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_search_restaurants
    - slot{"location": "chennai"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "hyderabad"}
    - slot{"location": "hyderabad"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - utter_ask_price
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_search_restaurants
    - slot{"location": "hyderabad"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye
* goodbye	





## interactive_story_4
* greet
    - utter_greet
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - utter_ask_price
* restaurant_search{"price": "lesser than 300"}
    - slot{"price": "lesser than 300"}
    - action_search_restaurants
    - slot{"location": "kolkata"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
* affirm
    - utter_goodbye
* goodbye	

## interactive_story_3	
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - utter_ask_details_email
* send_email{"sendEmail": "Yes"}
    - slot{"sendEmail": "Yes"}
    - utter_ask_emailId
* send_email{"emailId": "chaudhariabhishek25@gmail.com"}
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}
    - action_send_mail
    - slot{"emailId": "chaudhariabhishek25@gmail.com"}	
* affirm
    - utter_goodbye
* goodbye
