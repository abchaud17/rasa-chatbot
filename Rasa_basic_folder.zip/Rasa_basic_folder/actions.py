from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import pandas as pd
import json

ZomatoData = pd.read_csv('zomato.csv')
ZomatoData = ZomatoData.drop_duplicates().reset_index(drop=True)
WeOperate = ['New Delhi', 'Gurgaon', 'Noida', 'Faridabad', 'Allahabad', 'Bhubaneshwar', 'Mangalore', 'Mumbai', 'Ranchi',
             'Patna', 'Mysore', 'Aurangabad', 'Amritsar', 'Puducherry', 'Varanasi', 'Nagpur', 'Vadodara', 'Dehradun',
             'Vizag', 'Agra', 'Ludhiana', 'Kanpur', 'Lucknow', 'Surat', 'Kochi', 'Indore', 'Ahmedabad', 'Coimbatore',
             'Chennai', 'Guwahati', 'Jaipur', 'Hyderabad', 'Bangalore', 'Nashik', 'Pune', 'Kolkata', 'Bhopal', 'Goa',
             'Chandigarh', 'Ghaziabad', 'Ooty', 'Gangtok', 'Shimla']


def RestaurantSearch(City, Cuisine, price):
    if 'lesser' in price:
        TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (
            ZomatoData['City'].apply(lambda x: City.lower() in x.lower())) & (ZomatoData['Average Cost for two'] < 300)]
    if 'More' in price:
        TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (
            ZomatoData['City'].apply(lambda x: City.lower() in x.lower())) & (ZomatoData['Average Cost for two'] > 700)]
    else:
        TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (
            ZomatoData['City'].apply(lambda x: City.lower() in x.lower())) & (
                                  (ZomatoData['Average Cost for two'] > 300) & (
                                  ZomatoData['Average Cost for two'] < 700))]
    return TEMP[['Restaurant Name', 'Address', 'Average Cost for two', 'Aggregate rating']].sort_values(
        'Aggregate rating', ascending=False)


class ActionSearchRestaurants(Action):
    def name(self):
        return 'action_search_restaurants'

    def run(self, dispatcher, tracker, domain):
        # config={ "user_key":"f4924dc9ad672ee8c4f8c84743301af5"}
        loc = tracker.get_slot('location')
        cuisine = tracker.get_slot('cuisine')
        budget = tracker.get_slot('price')
        results = RestaurantSearch(City=loc, Cuisine=cuisine, price=budget)
        response = ""
        if results.shape[0] == 0:
            response = "no results"
        else:
            for restaurant in RestaurantSearch(loc, cuisine, budget).iloc[:5].iterrows():
                restaurant = restaurant[1]
                response = response + F"Found {restaurant['Restaurant Name']} in {restaurant['Address']} rated {restaurant['Address']} with avg cost {restaurant['Average Cost for two']} having rating {restaurant['Aggregate rating']} \n\n"

        dispatcher.utter_message("-----" + response)
        return [SlotSet('location', loc)]


class ActionSendMail(Action):
    def name(self):
        return 'action_send_mail'

    def run(self, dispatcher, tracker, domain):
        MailID = tracker.get_slot('emailId')
        need_email = tracker.get_slot('sendEmail')
        loc = tracker.get_slot('location')
        cuisine = tracker.get_slot('cuisine')
        budget = tracker.get_slot('price')
        results = RestaurantSearch(City=loc, Cuisine=cuisine, price=budget)
        response = ""
        if need_email.lower() == 'yes':
            if results.shape[0] == 0:
                response = "no results"
                dispatcher.utter_message("-----" + response)
            else:
                for restaurant in RestaurantSearch(loc, cuisine, budget).iloc[:10].iterrows():
                    restaurant = restaurant[1]
                    response = response + "\n" + "Restaurant Name: " + " " + restaurant['Restaurant Name'] + "\n" + "Restaurant Locality Address:" + " " + restaurant['Address'] + "\n" + "Average Budget of two people:" + " " + str(restaurant['Average Cost for two']) + "\n" + "Zomato User Rating:" + " " + str(restaurant['Aggregate rating']) + '\n'
                mail_content = response
                # The mail addresses and password
                sender_address = 'reticent2507@gmail.com'
                sender_pass = 'abhi@2507'
                receiver_address = MailID
                # Setup the MIME
                message = MIMEMultipart()
                message['From'] = sender_address
                message['To'] = receiver_address
                message['Subject'] = 'List of Restaurants for requested location'  # The subject line
                # The body and the attachments for the mail
                message.attach(MIMEText(mail_content, 'plain'))
                # Create SMTP session for sending the mail
                session = smtplib.SMTP('smtp.gmail.com', 587)  # use gmail with port
                session.starttls()  # enable security
                session.login(sender_address, sender_pass)  # login with mail_id and password
                text = message.as_string()
                session.sendmail(sender_address, receiver_address, text)
                session.quit()
                dispatcher.utter_message("-----" + 'Mail Sent')
        else:
            dispatcher.utter_message("-----" + "Goodbye")
        # sendmail(MailID, response)
        return [SlotSet('emailId', MailID)]
